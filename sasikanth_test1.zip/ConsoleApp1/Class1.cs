﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Class1
    {
        private int[] arr = new int[5];
        public int this [int i]
        {
            get { return arr[i]; }
            set { arr[i] = value; }
        }
    }
}
