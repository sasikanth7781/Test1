﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace ConsoleApp1
{ 
    class Program
    {
        public static void permutations(string org,string s="")
        {
            if (s.Length == org.Length)
            {
                Console.Write(s+" ");
                return;
            }
            for (int i = 0; i < org.Length; i++)
            {
                if (!s.Contains(org[i]))
                {
                    permutations(org, s + org[i]);
                }
            }

        }
        static void Main(string[] args)
        { //p1
            int[] arr;
            Console.WriteLine("Enter no.of elements:");
            int size=Convert.ToInt32(Console.ReadLine());
            arr = new int[size];
            int k = 0;
            while (k<size)
            {
                Console.WriteLine($"Enter element{k+1}");
                arr[k]=Convert.ToInt32(Console.ReadLine());
                k++;
            }
            Console.WriteLine($"sum is {arr.Sum()}");
            //p2
            int[,] twod = new int[3, 3];
            for (int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.WriteLine($"enter {i + 1} row {j + 1} column element:");
                    twod[i,j]=Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("the elements are");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(twod[i,j]+" ");
                }
                Console.WriteLine();
            }
            //p3
            string username="skreddy";
            string password="sk7781";
            while (true)
            {
                Console.WriteLine("enter user name");
                if (username == Console.ReadLine())
                {
                    Console.WriteLine("enter password");
                    while(password!= Console.ReadLine())
                    {
                        Console.WriteLine("enter correct password");
                    }
                    Console.WriteLine("Password entered successfully!");
                    break;
                }
            }
            //p4
            Console.WriteLine("enter number");
            int n = Convert.ToInt32(Console.ReadLine());
            string[] roman_symbol = { "MMM", "MM", "M", "CM", "DCCC", "DCC", "DC", "D", "CD", "CCC", "CC", "C", "XC", "LXXX", "LXX", "LX", "L", "XL", "XXX", "XX", "X", "IX", "VIII", "VII", "VI", "V", "IV", "III", "II", "I" };
            int[] int_value = { 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

            var roman_numerals = new StringBuilder();
            var index_num = 0;
            while (n != 0)
            {
                if (n >= int_value[index_num])
                {
                    n -= int_value[index_num];
                    roman_numerals.Append(roman_symbol[index_num]);
                }
                else
                {
                    index_num++;
                }
            }
            Console.WriteLine(roman_numerals.ToString());
            //p6
             string [] arr1;
             Console.WriteLine("Enter no.of elements:");
             int size1=Convert.ToInt32(Console.ReadLine());
             arr1 = new string[size1];
             int k1 = 0;
             while (k1<size1)
             {
                 Console.WriteLine($"Enter element{k1+1}");
                 arr1[k1]=Console.ReadLine();
                 k1++;
             }
            Console.WriteLine($"The Permutations with a combination of {size1} digits are :");
            permutations(String.Join("",arr1));

        }
    }
}
